import React from "react";

const BeerList = (props) => {
  const items = props.beers;
  console.log(items);
  return (
    <>
      <h1>Beers</h1>
      <ul className="list">
        {items.map((item) => (
          <li key={item._id} className="beer">
            <div>Name: {item.name}</div>
            Brevery:
            <a href={"brewery/" + String(item.brewer).replace(" ", "")}>
              {" "}
              {item.brewer}
            </a>
            <div>Abv: {item.abv}</div>
            <div>Price: {item.price}</div>
            <img
              className="card-image"
              src={"data:image/png;base64," + item.img}
            />
            <hr />
            <br />
          </li>
        ))}
      </ul>
    </>
  );
};

export default BeerList;
