export default function BreweriesList(props) {
  const items = props.breweries;
  return (
    <>
      <h1>Breweries</h1>
      <ul className="list">
        {items.map((item) => (
          <li id={item.name}>
            <div>Name: {item.name}</div>
            <a href={"https://" + item.url}>{item.url}</a>
            <div>Country: {item.country}</div>
            <div>Description: {item.description}</div>
            <a href={"brewery/" + item.name}>
              <img
                className="card-image"
                src={"data:image/png;base64," + item.img}
              />
            </a>
            <hr />
            <br />
          </li>
        ))}
      </ul>
    </>
  );
}
