import React from "react";

const Navbar = () => {
  return (
    <nav>
      <div className="nav-wrapper">
        <h1 className="nav-block">Beerana</h1>

        <ul className="list navigation">
          <li className="nav-block">
            <a href="/">Beers</a>
          </li>
          <li className="nav-block">
            <a href="/brewery">Breweries</a>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
