import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import PageNotFound from "./components/PageNotFound";
import Breweries from "./pages/Breweries";
import Brewery from "./pages/Brewery";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/brewery/:slug",
    element: <Brewery />,
  },
  {
    path: "/brewery",
    element: <Breweries />,
  },
  {
    path: "*",
    element: <PageNotFound />,
  },
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
