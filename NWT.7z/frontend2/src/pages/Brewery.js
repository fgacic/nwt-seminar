import React from "react";
import BreweriesList from "../components/BreweriesList";
import Navbar from "../components/NavBar";
import { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function Breweries() {
  const slug = useParams().slug;
  const options = {
    url: `http://localhost:3000/brewery/${slug}`,
    method: "GET",
  };
  const [response, setresponse] = useState(false);
  useEffect(() => {
    axios(options)
      .then((response) => {
        console.log(response.data);
        response != [] && setresponse(response.data);
      })
      .catch((response) => {
        console.log(response);
      });
  }, []);
  if (response)
    return (
      <>
        <Navbar />
        <BreweriesList breweries={response} />
      </>
    );
  else {
    return <h1>Loading</h1>;
  }
}
