import React from "react";
import BreweriesList from "../components/BreweriesList";
import Navbar from "../components/NavBar";
import { useEffect, useState } from "react";
import axios from "axios";

const options = {
  url: "http://localhost:3000/brewery",
  method: "GET",
};
export default function Breweries() {
  const [response, setresponse] = useState(false);
  useEffect(() => {
    axios(options)
      .then((response) => {
        console.log(response.data);
        setresponse(response.data);
      })
      .catch((response) => {
        console.log(response);
      });
  }, []);
  if (response)
    return (
      <>
        <Navbar />
        <BreweriesList breweries={response} />
      </>
    );
  else {
    return <h1>Loading</h1>;
  }
}
