const mongoose = require("mongoose");
const express = require("express");
const cors = require("cors");
let app = express();
app.use(express.json());
app.use(cors());
require("dotenv").config();
const beerController = require("./controllers/beerController");
const brewerController = require("./controllers/brewerController");
const userController = require("./controllers/userController");

// Connect to the MongoDB server
mongoose.connect(
  "mongodb+srv://root:PNAOU22O42omPxEu@cluster0.kkk7fjk.mongodb.net/?retryWrites=true&w=majority",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);

app.get("/", (req, res) => res.send("Hello world"));
app.use("/beers", beerController);
app.use("/brewery", brewerController);
app.use("/auth", userController);

app.listen(process.env.PORT);
